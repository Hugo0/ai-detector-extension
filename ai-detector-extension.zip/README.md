# AI Detector: Em Dashes & Unicode Spaces Highlighter

Highlights em dashes (—) and selected non-standard Unicode spaces on any webpage. Useful for spotting formatting artifacts often seen in AI-generated text.

## What it highlights

- Em dash (U+2014)
- No-break space (U+00A0)
- En quad (U+2000)
- Em quad (U+2001)
- Six-per-em space (U+2006)
- Figure space (U+2007)
- Punctuation space (U+2008)
- Thin space (U+2009)
- Hair space (U+200A)
- Ideographic space (U+3000)

Note: Regular ASCII space (U+0020) is intentionally not highlighted to avoid overwhelming the page. If you want it, we can add an option.

## Install (Chrome)

1. Download or clone this folder.
2. Open Chrome and go to `chrome://extensions`.
3. Enable "Developer mode" (top-right).
4. Click "Load unpacked" and select the project folder.

The content script runs automatically on all pages you visit.

## How it works

- Scans text nodes and wraps target characters in `<span>` elements with a highlight class.
- Uses a `MutationObserver` to handle dynamic content.
- Avoids editing inside inputs, code blocks, pre tags, and editable content.

## Uninstall

Remove the extension from `chrome://extensions`.
